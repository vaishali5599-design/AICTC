# Data

Download the PhiUSIIL Phishing URL (Website) dataset from the UCI Machine Learning Repository (dataset 967, https://archive.ics.uci.edu/dataset/967, CC BY 4.0) and place
`PhiUSIIL_Phishing_URL_Dataset.csv` in this folder. The data are not redistributed here.

SHA-256 of the file used for the reported results: `a236549cd369cd80bd478ff8e1779cbf44c58d5c3f79f7a51a1adbed7d06d1c6`
