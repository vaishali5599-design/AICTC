"""Figures for the AICTC-2027 paper (Springer text width 12.2 cm). Run after run_experiments.py."""
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.patches import FancyBboxPatch

sys.stdout.reconfigure(encoding="utf-8")
ROOT = Path(__file__).resolve().parent
RES, FIG = ROOT / "results", ROOT / "figures"; FIG.mkdir(exist_ok=True)
C1, C2, C3, GREY, INK, INK2, GRID = "#2a78d6", "#eb6834", "#1baf7a", "#8c8b87", "#0b0b0b", "#52514e", "#dddcd8"
plt.rcParams.update({"font.family": "serif", "font.serif": ["Times New Roman", "DejaVu Serif"], "font.size": 8,
                     "axes.edgecolor": INK2, "axes.labelcolor": INK, "xtick.color": INK2, "ytick.color": INK2,
                     "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.color": GRID,
                     "grid.linewidth": 0.5, "axes.axisbelow": True, "legend.frameon": False, "savefig.dpi": 600,
                     "savefig.bbox": "tight", "lines.linewidth": 1.3})
W = 4.6
LABEL = {"format_rule": "Format rule (no learning)", "url_provided": "URL features (provided, 18)",
         "url_lexical": "URL lexical (ours, full URL)", "safe_numeric": "Safe numeric (URL + page)",
         "all_numeric": "All numeric (incl. 4 flagged)", "host_only": "Host-only lexical (ours)"}
ORDER = ["format_rule", "url_provided", "url_lexical", "safe_numeric", "all_numeric", "host_only"]
A = pd.read_csv(RES / "all_runs.csv")

# ------------------------------------------------------------ Fig. 1 evaluation workflow
fig, ax = plt.subplots(figsize=(W, 1.35)); ax.set_axis_off(); ax.set_xlim(0, 10); ax.set_ylim(0.2, 2.4)
boxes = [(0.05, 1.15, "PhiUSIIL\n235,795 URLs\n(UCI 967)"), (2.05, 1.15, "Shortcut audit\n(format rule,\n1-feature AUC)"),
         (4.05, 1.15, "5 seeds ×\nrandom / host /\neTLD+1 split"), (6.05, 1.15, "5 feature sets\n× LR, RF, HGB\nPlatt, FPR cap"),
         (8.05, 1.15, "Test sets:\nall, format-\nmatched, perturbed")]
for x, yb, t in boxes:
    ax.add_patch(FancyBboxPatch((x, yb), 1.85, 1.15, boxstyle="round,pad=0.03,rounding_size=0.12",
                                fc="#eef4fc", ec=C1, lw=0.8))
    ax.text(x + 0.925, yb + 0.575, t, ha="center", va="center", fontsize=6.0, color=INK, linespacing=1.15)
for x in (1.9, 3.9, 5.9, 7.9):
    ax.annotate("", xy=(x + 0.15, 1.725), xytext=(x, 1.725), arrowprops=dict(arrowstyle="-|>", color=INK2, lw=0.8))
ax.text(5.0, 0.6, "Imputation, scaling, one-hot encoding, calibration and thresholds use training/validation data only;\n"
        "in grouped designs, test hosts or registrable domains never appear in training.", ha="center", va="center",
        fontsize=6.2, color=INK2)
fig.savefig(FIG / "fig1_workflow.png"); plt.close(fig); print("fig1")

# ------------------------------------------------------------ Fig. 2 headline score vs. format-matched recall
sel = A[(A.split == "reg") & (((A.model == "hgb") & (A.calibration == "raw")) | (A.model == "rule"))]
fig, axes = plt.subplots(1, 2, figsize=(W, 2.05), sharey=True, gridspec_kw={"wspace": 0.08})
ys = np.arange(len(ORDER))[::-1]
for ax, (subset, metric, title, xl) in zip(axes, (("all", "pr_auc", "(a) All test URLs", "PR-AUC"),
                                                  ("format_matched", "recall", "(b) Format-matched test URLs",
                                                   "phishing recall at 0.5"))):
    for yv, fs in zip(ys, ORDER):
        d = sel[(sel.features == fs) & (sel.subset == subset)][metric]
        if fs == "format_rule" and subset == "format_matched":
            d = pd.Series([0.0] * 5)                               # rule labels every format-matched URL legitimate
        col = GREY if fs == "format_rule" else (C3 if fs == "host_only" else C1)
        ax.errorbar(d.mean(), yv, xerr=d.std(ddof=1) if len(d) > 1 else 0, fmt="o", color=col, ms=4.5, capsize=2,
                    elinewidth=0.8)
        ax.text(d.mean() + (0.03 if metric == "recall" else 0.006), yv + 0.28, f"{d.mean():.3f}", fontsize=6.3,
                color=INK2, ha="left" if metric == "recall" else "right")
    ax.set_title(title, fontsize=7.5, loc="left"); ax.set_xlabel(xl)
axes[0].set_xlim(0.80, 1.006); axes[1].set_xlim(-0.03, 1.08)
axes[0].set_yticks(ys); axes[0].set_yticklabels([LABEL[f] for f in ORDER], fontsize=6.8)
fig.savefig(FIG / "fig2_format_matched.png"); plt.close(fig); print("fig2")

# ------------------------------------------------------------ Fig. 3 perturbations of legitimate URLs
P = pd.read_csv(RES / "perturbation.csv")
var = ["original", "trailing_slash", "index_path", "http_scheme", "no_www"]
vlab = ["original\nhttps://www.h", "trailing\nslash", "/index.html\npath", "http://\nscheme", "www.\nremoved"]
fig, ax = plt.subplots(figsize=(W, 1.9))
x = np.arange(len(var)); bw = 0.36
for i, (fs, col, lab, hatch) in enumerate((("url_lexical", C1, "URL lexical model (full URL)", ""),
                                           ("host_only", C3, "Host-only model", "///"))):
    m = [P[(P.features == fs) & (P.variant == v)].fpr.mean() * 100 for v in var]
    s = [P[(P.features == fs) & (P.variant == v)].fpr.std(ddof=1) * 100 for v in var]
    ax.bar(x + (i - 0.5) * bw, m, bw * 0.92, yerr=s, color=col, hatch=hatch, edgecolor="white", lw=0.4, capsize=2,
           error_kw=dict(elinewidth=0.7), label=lab)
    for xi, mi in zip(x, m):
        ax.text(xi + (i - 0.5) * bw, mi + 2.5, f"{mi:.1f}", ha="center", fontsize=6.2, color=INK2)
ax.set_xticks(x); ax.set_xticklabels(vlab, fontsize=6.6); ax.set_ylim(0, 112)
ax.set_ylabel("legitimate URLs flagged (%)")
ax.legend(fontsize=6.6, loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=2)
fig.savefig(FIG / "fig3_perturbation.png"); plt.close(fig); print("fig3")

# ------------------------------------------------------------ Fig. 4 reliability of the host-only model
_pp = RES / "predictions_reg_seed0.csv"
Pr = pd.read_csv(_pp if _pp.exists() else _pp.with_suffix(".csv.gz"))   # the public release ships the .gz
d = Pr[(Pr.features == "host_only") & (Pr.model == "hgb")]
fig, ax = plt.subplots(figsize=(2.6, 2.4))
ax.plot([0, 1], [0, 1], ls=":", color=GREY, lw=1, label="ideal")
for col, mk, ls, lab, key in ((C1, "o", "-", "raw", "p_raw"), (C2, "s", "--", "Platt (validation)", "p_platt")):
    e = np.linspace(0, 1, 11); xs, yv = [], []
    for lo, hi in zip(e[:-1], e[1:]):
        m = (d[key] >= lo) & ((d[key] < hi) if hi < 1 else (d[key] <= hi))
        if m.sum() >= 20:
            xs.append(d[key][m].mean()); yv.append(d.y[m].mean())
    ax.plot(xs, yv, color=col, marker=mk, ms=3.5, ls=ls, label=lab)
ax.set_xlabel("predicted phishing probability"); ax.set_ylabel("observed phishing share")
ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.set_aspect("equal"); ax.legend(fontsize=6.6, loc="upper left")
fig.savefig(FIG / "fig4_reliability.png"); plt.close(fig); print("fig4")
