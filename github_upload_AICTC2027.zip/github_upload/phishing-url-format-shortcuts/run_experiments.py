"""AICTC-2027 study: format shortcuts and leakage-aware evaluation of phishing URL detection on PhiUSIIL.

Extends the authors' notebook (sydney_conference.ipynb: random vs. host-disjoint split, three feature policies, three
learners, validation-only Platt calibration) with
  E1  repeated splits (5 seeds) and a stricter registrable-domain (eTLD+1) grouping,
  E2  a zero-parameter URL-format rule and single-feature AUCs (shortcut audit),
  E3  evaluation restricted to test URLs that share the legitimate URL format (format-matched subset),
  E4  host-only lexical features computed from the hostname (format-neutral representation),
  E5  format perturbations of legitimate test URLs (trailing slash, path, http scheme, no www),
  E6  validation-chosen thresholds at a fixed false-positive budget, transferred to the test set.
Usage: python run_experiments.py [--seeds 5]
"""
import argparse
import json
import math
import platform
import re
import time
from collections import Counter
from pathlib import Path
from urllib.parse import urlsplit

import numpy as np
import pandas as pd
import sklearn
import tldextract
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (average_precision_score, brier_score_loss, confusion_matrix, f1_score,
                             precision_score, recall_score, roc_auc_score)
from sklearn.model_selection import GroupShuffleSplit, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data" / "PhiUSIIL_Phishing_URL_Dataset.csv"
OUT = ROOT / "results"

URL_FEATURES = ['URLLength', 'DomainLength', 'IsDomainIP', 'NoOfSubDomain', 'HasObfuscation', 'NoOfObfuscatedChar',
                'ObfuscationRatio', 'NoOfLettersInURL', 'LetterRatioInURL', 'NoOfDegitsInURL', 'DegitRatioInURL',
                'NoOfEqualsInURL', 'NoOfQMarkInURL', 'NoOfAmpersandInURL', 'NoOfOtherSpecialCharsInURL',
                'SpacialCharRatioInURL', 'IsHTTPS', 'URLDepth', 'TLDLength']
SUSPECT = ['URLSimilarityIndex', 'TLDLegitimateProb', 'URLCharProb', 'CharContinuationRate']
NON_FEATURES = {'FILENAME', 'URL', 'Domain', 'TLD', 'Title', 'label'}
CANON = re.compile(r"https://www\.[^/?#\s]+")          # the form of every legitimate URL in PhiUSIIL
EXT = tldextract.TLDExtract(suffix_list_urls=())      # bundled public-suffix snapshot, no network access


# ------------------------------------------------------------------ data
def load():
    df = pd.read_csv(DATA, low_memory=False)
    df["y"] = (df["label"] == 0).astype(int)           # original coding 0 = phishing; internal 1 = phishing
    host = df["Domain"].fillna("").astype(str).str.lower().str.strip().str.strip(".")
    df = df[host.ne("")].reset_index(drop=True)
    host = host[host.ne("")].reset_index(drop=True)
    df["host"] = host.str.replace(r"^www\.", "", regex=True)
    df["reg"] = df["host"].map(lambda h: EXT(h).top_domain_under_public_suffix or h)
    df["canonical"] = df["URL"].astype(str).map(lambda u: bool(CANON.fullmatch(u)))
    return df


def entropy(s):
    if not s:
        return 0.0
    c = Counter(s); n = len(s)
    return -sum(v / n * math.log2(v / n) for v in c.values())


def host_features(h):
    """Lexical features of the hostname without scheme, 'www.' and path (identical for any URL format)."""
    labels = h.split(".")
    digits = sum(ch.isdigit() for ch in h); letters = sum(ch.isalpha() for ch in h)
    vowels = sum(ch in "aeiou" for ch in h)
    sld = EXT(h).domain or labels[0]
    return dict(h_len=len(h), h_labels=len(labels), h_digits=digits, h_digit_ratio=digits / max(len(h), 1),
                h_hyphens=h.count("-"), h_entropy=entropy(h), h_max_label=max(map(len, labels)),
                h_vowel_ratio=vowels / max(letters, 1), h_sld_len=len(sld), h_sld_digits=sum(c.isdigit() for c in sld),
                h_is_ip=int(bool(re.fullmatch(r"[\d.]+", h))), h_xn=int("xn--" in h))


def url_features(u):
    """Lexical features of the full URL string (scheme, www, path and query included)."""
    s = urlsplit(u if "://" in u else "http://" + u)
    host = (s.hostname or "").lower()
    f = {"u_len": len(u), "u_https": int(s.scheme == "https"), "u_www": int(host.startswith("www.")),
         "u_path_len": len(s.path), "u_slashes": u.count("/"), "u_query": int(bool(s.query)),
         "u_eq": u.count("="), "u_amp": u.count("&"), "u_end_slash": int(u.endswith("/")),
         "u_digits": sum(c.isdigit() for c in u), "u_special": sum(not c.isalnum() for c in u)}
    f.update(host_features(re.sub(r"^www\.", "", host)))
    return f


def tld_of(h):
    return EXT(h).suffix or h.rsplit(".", 1)[-1]


# ------------------------------------------------------------------ models and splits
def make_model(name, num_cols, cat_cols=()):
    num = Pipeline([("imp", SimpleImputer(strategy="median"))] + ([("sc", StandardScaler())] if name == "logistic" else []))
    pre = ColumnTransformer([("num", num, list(num_cols))] +
                            ([("cat", OneHotEncoder(handle_unknown="infrequent_if_exist", min_frequency=50,
                                                    sparse_output=False), list(cat_cols))] if cat_cols else []))
    if name == "logistic":
        clf = LogisticRegression(max_iter=2000, random_state=42)
    elif name == "rf":
        clf = RandomForestClassifier(n_estimators=160, min_samples_leaf=3, n_jobs=-1, random_state=42)
    else:
        clf = HistGradientBoostingClassifier(max_iter=160, max_leaf_nodes=20, learning_rate=0.07,
                                             l2_regularization=1.0, random_state=42)
    return Pipeline([("pre", pre), ("clf", clf)])


def split(df, kind, seed):
    idx = np.arange(len(df))
    if kind == "random":
        a, te = train_test_split(idx, test_size=0.2, random_state=seed, stratify=df.y)
        tr, va = train_test_split(a, test_size=0.25, random_state=seed + 100, stratify=df.y.iloc[a])
        return tr, va, te
    g = df["host" if kind == "host" else "reg"].to_numpy()
    a, te = next(GroupShuffleSplit(1, test_size=0.2, random_state=seed).split(idx, df.y, g))
    tr, va = next(GroupShuffleSplit(1, test_size=0.25, random_state=seed + 100).split(a, df.y.iloc[a], g[a]))
    tr, va = a[tr], a[va]
    assert not (set(g[tr]) & set(g[te])) and not (set(g[tr]) & set(g[va]))
    return tr, va, te


# ------------------------------------------------------------------ metrics
def platt(yv, pv):
    z = lambda p: np.log(np.clip(p, 1e-6, 1 - 1e-6) / (1 - np.clip(p, 1e-6, 1 - 1e-6))).reshape(-1, 1)
    cal = LogisticRegression(C=1e4, max_iter=1000).fit(z(pv), yv)
    return lambda p: cal.predict_proba(z(p))[:, 1]


def ece(y, p, bins=10):
    e = np.linspace(0, 1, bins + 1); out = 0.0
    for lo, hi in zip(e[:-1], e[1:]):
        m = (p >= lo) & ((p < hi) if hi < 1 else (p <= hi))
        if m.any():
            out += m.mean() * abs(y[m].mean() - p[m].mean())
    return float(out)


def scores(y, p, t=0.5):
    pred = (p >= t).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    both = len(np.unique(y)) == 2
    return dict(pr_auc=average_precision_score(y, p) if both else np.nan,
                roc_auc=roc_auc_score(y, p) if both else np.nan,
                precision=precision_score(y, pred, zero_division=0), recall=recall_score(y, pred, zero_division=0),
                f1=f1_score(y, pred, zero_division=0), fpr=fp / max(fp + tn, 1), fp=int(fp), fn=int(fn),
                brier=brier_score_loss(y, p), ece=ece(y, p))


def thr_at_fpr(yv, pv, budget):
    """Smallest validation threshold whose validation FPR does not exceed the budget."""
    neg = np.sort(pv[yv == 0])[::-1]
    k = int(math.floor(budget * len(neg)))
    return float(np.nextafter(neg[k], 1)) if k < len(neg) else 0.0


# ------------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--seeds", type=int, default=5)
    args = ap.parse_args()
    OUT.mkdir(exist_ok=True); t0 = time.time()
    df = load()
    print("records", len(df), "hosts", df.host.nunique(), "registrable domains", df.reg.nunique(),
          "phishing share %.4f" % df.y.mean())

    global URL_FEATURES
    URL_FEATURES = [c for c in URL_FEATURES if c in df.columns]      # URLDepth is absent from the UCI release
    H = pd.DataFrame([host_features(h) for h in df.host]); H["tld"] = [tld_of(h) for h in df.host]
    U = pd.DataFrame([url_features(u) for u in df.URL.astype(str)]); U["tld"] = H["tld"]
    num_all = [c for c in df.columns if c not in NON_FEATURES | {"y", "host", "reg", "canonical"}
               and pd.api.types.is_numeric_dtype(df[c])]
    page = [c for c in num_all if c not in URL_FEATURES + SUSPECT]
    FS = {"url_provided": (df[URL_FEATURES], URL_FEATURES, []),
          "safe_numeric": (df[[c for c in num_all if c not in SUSPECT]], [c for c in num_all if c not in SUSPECT], []),
          "all_numeric": (df[num_all], num_all, []),
          "url_lexical": (U, [c for c in U.columns if c != "tld"], ["tld"]),
          "host_only": (H, [c for c in H.columns if c != "tld"], ["tld"])}
    y = df.y.to_numpy(); canon = df.canonical.to_numpy()

    # ---- E2 shortcut audit (no learning)
    audit = {"records": len(df), "hosts": int(df.host.nunique()), "registrable_domains": int(df.reg.nunique()),
             "phishing": int(y.sum()), "legitimate": int((1 - y).sum()),
             "legit_canonical_share": float(canon[y == 0].mean()), "phish_canonical_share": float(canon[y == 1].mean()),
             "phish_canonical_n": int(canon[y == 1].sum()),
             "reg_domains_with_both_classes": int((df.groupby("reg").y.nunique() == 2).sum()),
             "rows_in_mixed_reg_domains": int(df.reg.isin(df.groupby("reg").y.nunique().loc[lambda s: s == 2].index).sum()),
             "duplicate_urls": int(df.URL.duplicated().sum()),
             "top_reg_domains": df.reg.value_counts().head(10).to_dict()}
    rule = (~canon).astype(float)
    audit["rule_non_canonical_is_phishing"] = {k: float(v) if isinstance(v, (float, np.floating)) else v
                                               for k, v in scores(y, rule).items()}
    audit["rule_accuracy"] = float(((rule >= 0.5) == y).mean())
    uni = []
    for c in num_all + list(H.columns.drop("tld")) + list(U.columns.drop(["tld"] + list(H.columns.drop("tld")), errors="ignore")):
        src = df[c] if c in df else (H[c] if c in H else U[c])
        a = roc_auc_score(y, src.fillna(src.median()))
        uni.append(dict(feature=c, group=("page/other" if c in page else "suspect" if c in SUSPECT else
                                          "url_provided" if c in URL_FEATURES else "host_only" if c in H else "url_lexical"),
                        auc=max(a, 1 - a), legit_median=float(src[y == 0].median()), phish_median=float(src[y == 1].median())))
    pd.DataFrame(uni).sort_values("auc", ascending=False).to_csv(OUT / "univariate_auc.csv", index=False)
    print("audit done %.0fs" % (time.time() - t0), json.dumps({k: v for k, v in audit.items() if k != "top_reg_domains"}, default=str)[:600])

    # ---- E1, E3, E4, E6: repeated splits
    rows, preds = [], []
    for seed in range(args.seeds):
        for kind in ("random", "host", "reg"):
            tr, va, te = split(df, kind, seed)
            rs = scores(y[te], rule[te])
            rows.append(dict(seed=seed, split=kind, features="format_rule", model="rule", calibration="none",
                             subset="all", n=len(te), **rs))
            for fs, (X, num, cat) in FS.items():
                for mdl in ("logistic", "rf", "hgb"):
                    if mdl == "rf" and seed > 0 and kind == "random":
                        continue                                   # RF on random splits: seed 0 only (cost)
                    m = make_model(mdl, num, cat); tic = time.time()
                    m.fit(X.iloc[tr], y[tr]); fit_s = time.time() - tic
                    pv = m.predict_proba(X.iloc[va])[:, 1]; pt = m.predict_proba(X.iloc[te])[:, 1]
                    cal = platt(y[va], pv); pc = cal(pt)
                    for state, p, pval in (("raw", pt, pv), ("platt", pc, cal(pv))):
                        base = dict(seed=seed, split=kind, features=fs, model=mdl, calibration=state, fit_s=fit_s)
                        rows.append(dict(base, subset="all", n=len(te), **scores(y[te], p)))
                        cm = canon[te]                                # E3 format-matched test subset
                        rows.append(dict(base, subset="format_matched", n=int(cm.sum()),
                                         n_phish=int(y[te][cm].sum()), **scores(y[te][cm], p[cm])))
                        for budget in (0.01, 0.001):                # E6 validation-chosen threshold
                            t = thr_at_fpr(y[va], pval, budget)
                            rows.append(dict(base, subset=f"fpr_budget_{budget}", n=len(te), threshold=t,
                                             **scores(y[te], p, t)))
                    if seed == 0 and kind == "reg":
                        preds.append(pd.DataFrame({"features": fs, "model": mdl, "y": y[te], "p_raw": pt, "p_platt": pc,
                                                   "canonical": canon[te]}))
                    print(f"seed {seed} {kind:6s} {fs:13s} {mdl:8s} PR-AUC {average_precision_score(y[te], pt):.4f} "
                          f"fmt-matched recall {recall_score(y[te][canon[te]], pt[canon[te]] >= 0.5):.3f} "
                          f"[{time.time() - t0:.0f}s]", flush=True)
            pd.DataFrame(rows).to_csv(OUT / "all_runs.csv", index=False)

    # ---- E5 perturbations of legitimate test URLs (eTLD+1 split, HGB), seeds as above
    pert = []
    variants = {"original": lambda u: u, "trailing_slash": lambda u: u + "/",
                "index_path": lambda u: u + "/index.html", "http_scheme": lambda u: u.replace("https://", "http://", 1),
                "no_www": lambda u: u.replace("://www.", "://", 1)}
    for seed in range(args.seeds):
        tr, va, te = split(df, "reg", seed)
        leg = te[y[te] == 0]
        for fs in ("url_lexical", "host_only"):
            X, num, cat = FS[fs]
            m = make_model("hgb", num, cat).fit(X.iloc[tr], y[tr])
            for vname, fn in variants.items():
                urls = df.URL.iloc[leg].astype(str).map(fn)
                if fs == "url_lexical":
                    Xp = pd.DataFrame([url_features(u) for u in urls]); Xp["tld"] = H["tld"].iloc[leg].to_numpy()
                else:
                    hosts = [re.sub(r"^www\.", "", (urlsplit(u).hostname or "").lower()) for u in urls]
                    Xp = pd.DataFrame([host_features(h) for h in hosts]); Xp["tld"] = [tld_of(h) for h in hosts]
                p = m.predict_proba(Xp)[:, 1]
                pert.append(dict(seed=seed, features=fs, variant=vname, n_legit=len(leg), fpr=float((p >= 0.5).mean()),
                                 mean_p=float(p.mean())))
        print("perturbation seed", seed, "done", flush=True)
    pd.DataFrame(pert).to_csv(OUT / "perturbation.csv", index=False)
    pd.concat(preds).to_csv(OUT / "predictions_reg_seed0.csv", index=False)

    audit.update(python=platform.python_version(), sklearn=sklearn.__version__, numpy=np.__version__,
                 pandas=pd.__version__, tldextract=tldextract.__version__, seeds=args.seeds,
                 runtime_s=round(time.time() - t0), feature_sets={k: list(v[1]) + list(v[2]) for k, v in FS.items()})
    import hashlib
    audit["data_sha256"] = hashlib.sha256(DATA.read_bytes()).hexdigest()
    (OUT / "audit.json").write_text(json.dumps(audit, indent=2, default=str), encoding="utf-8")
    print("done in %.0fs" % (time.time() - t0))


if __name__ == "__main__":
    main()
