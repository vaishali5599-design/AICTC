# Format shortcuts in phishing URL benchmarks (PhiUSIIL)

Code and results for the conference paper *Format Shortcuts in Phishing URL Benchmarks: A Leakage-Aware and
Format-Neutral Evaluation on PhiUSIIL* (submitted to AICTC-2027).

Every legitimate URL in PhiUSIIL has the form `https://www.<host>`, while only 627 of
100,945 phishing URLs do. The study measures how much of the near-perfect benchmark performance comes from
this format cue, using grouped splits, a format-matched test subset, format perturbations of legitimate URLs and a
host-only lexical baseline.

## Contents

| Path | Content |
|---|---|
| `run_experiments.py` | Shortcut audit; random, hostname-disjoint and registrable-domain (eTLD+1) disjoint splits over 5 seeds; five feature policies; logistic regression, random forest, histogram gradient boosting; validation-only Platt calibration; thresholds at validation false-positive budgets; format-matched evaluation; perturbation test |
| `make_figures.py` | The four figures of the paper from `results/` |
| `notebooks/sydney_conference.ipynb` | The original exploratory notebook (Google Colab) |
| `results/` | `all_runs.csv`, `perturbation.csv`, `univariate_auc.csv`, `audit.json` (counts, format rule, versions, data hash), `predictions_reg_seed0.csv.gz` |
| `figures/` | Workflow, format-matched comparison, perturbation test, reliability diagram (600 dpi) |
| `data/` | Place the UCI CSV here (not redistributed) |

## Running

```bash
pip install -r requirements.txt
# download PhiUSIIL_Phishing_URL_Dataset.csv into data/ (see data/README.md)
python run_experiments.py --seeds 5   # about 30 min on a laptop CPU, writes results/
python make_figures.py                # writes figures/
```

All imputation, scaling, encoding, calibration and threshold choices use the training or validation part of each
split only. The perturbation test edits legitimate test URLs offline; no web page is visited.

## Main results

| Quantity | Value |
|---|---|
| Format rule (non-canonical URL = phishing), whole dataset | accuracy 99.73 %, precision 1.000, recall 0.9938 |
| Distinct hostnames / registrable domains | 219,103 / 175,509 of 235,795 records |

See the paper and `results/all_runs.csv` for the model results (mean ± SD over five seeds).

Reported results were produced with Python 3.11.9, scikit-learn 1.9.1, NumPy 2.4.6, pandas
3.0.6 and tldextract 5.4.0 (bundled public suffix list).

## Data

Prasad, A., Chandra, S. (2024). PhiUSIIL Phishing URL (Website). UCI Machine Learning Repository (CC BY 4.0).
Paper: https://doi.org/10.1016/j.cose.2023.103545

## License

MIT (see `LICENSE`).
